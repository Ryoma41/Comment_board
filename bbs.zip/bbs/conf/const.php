<?php

// データベースの接続情報
define('DB_USER',   'root');  // MySQLのユーザ名
define('DB_PASSWD', 'root');    // MySQLのパスワード
define('DNS', 'mysql:dbname=bbs;host=localhost;port=8889;charset=utf8');  // データベースのDNS情報

define('HTML_CHARACTER_SET', 'UTF-8');  // HTML文字エンコーディング
define('DB_CHARACTER_SET',   'UTF8');   // DB文字エンコーディング

define('IMG_DIR', './img/');   // 画像ファイル保存ディレクトリ